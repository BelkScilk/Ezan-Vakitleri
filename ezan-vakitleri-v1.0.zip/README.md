# Ezan Vakitleri

Ezan vakitlerini ve **kerahat vaktine ne kadar kaldığını** gösteren, internet gerektirmeyen bir Android uygulaması.

## Neler yapar

- Seçtiğiniz ilin (81 il) ya da bulunduğunuz konumun **İmsak, Güneş, Öğle, İkindi, Akşam, Yatsı** vakitlerini gösterir; sıradaki vakte kalan süreyi saniye saniye sayar.
- Ana ekrandaki **güneş kadranı**, günü saat 12'si tepede olacak şekilde bir halka olarak çizer: gündüz bandı, üç kerahat vakti (mercan rengi) ve güneşin/ayın o anki yeri görünür. Ortadaki sayaç kerahat vaktine, kerahat vakti içindeyseniz bitmesine kalan süreyi gösterir.
- **Kerahat vakitleri** (Hanefî): güneş doğarken, istiva (güneşin tam tepede olduğu an) ve güneş batarken. Süreler ayarlardan değiştirilebilir (varsayılan: 45 / 10 / 45 dakika).
- Sistemin **açık/koyu temasını** izler.
- Tamamen çevrimdışıdır; **internet izni yoktur**. Konum izni yalnızca "Konumumu kullan" düğmesine bastığınızda istenir ve konumunuz cihazdan çıkmaz.

## Vakitler nasıl hesaplanıyor?

Vakitler cihazda, Diyanet İşleri Başkanlığı'nın yöntemiyle hesaplanır (`app/src/main/assets/www/engine.js`):

| Vakit | Ölçüt |
| --- | --- |
| İmsak | Güneş ufkun 18° altında |
| Güneş / Akşam | Güneşin üst kenarı ufukta (−0,833°) |
| Öğle | Güneşin meridyen geçişi |
| İkindi | Gölge boyu = cismin boyu |
| Yatsı | Güneş ufkun 17° altında |

Diyanet'in yayımladığı ihtiyat payları (Güneş −7, Öğle +5, İkindi +4, Akşam +7 dakika) uygulanır.

Doğruluk, Diyanet'in yayımladığı değerlerle karşılaştırılarak denetlendi: kalibrasyon için kullanılan 306 değerin %96'sı, örnek dışı tutulan il tablolarındaki 348 değerin %98,6'sı dakikası dakikasına aynı çıktı; hiçbiri 1 dakikadan fazla sapmadı. Vakitler il merkezi koordinatıyla hesaplanır; ilçelerde Diyanet takvimiyle birkaç dakikalık fark olabilir. "Konumumu kullan" dediğinizde hesap tam konumunuza göre yapılır.

## Kerahat süreleri hakkında

Kaynaklar süreleri kesin bir sayıyla değil aralıkla verir (güneş doğduktan sonra yaklaşık 40–50 dakika, batmadan önce yaklaşık 40–50 dakika, istiva için birkaç dakika). Varsayılanlar bu aralıkların ortasındadır; kendi ilmihalinize göre ayarlayabilirsiniz (sağ üstteki ayar düğmesi). Dini bir hüküm gerektiren durumlarda Diyanet İşleri Başkanlığı'na danışın.

## APK üretme (GitHub Actions)

1. Bu zip'i GitHub deposunun **köküne** yükleyin (depo kökünde başka `.zip` olmasın; iş akışı bulduğu ilk zip'i açar).
2. `build.yml` dosyasını deponuzda `.github/workflows/build.yml` olarak ekleyin.
3. **Actions** sekmesinde "Ezan Vakitleri APK Derle" çalışınca sonuç `ezan-vakitleri-apk` adlı çıktıda `ezan-vakitleri.apk` olarak iner.

İş akışı sırasıyla: Java 17, Gradle 8.9, Android SDK 35 (build-tools 35.0.0) kurar; zip'i açar ve `gradle assembleDebug` çalıştırır.

Yerelde derlemek için Android Studio'da klasörü açmanız ya da `./gradlew assembleDebug` çalıştırmanız yeterlidir (APK: `app/build/outputs/apk/debug/app-debug.apk`).

## Proje yapısı

```
app/src/main/
  java/tr/ezanvakitleri/app/MainActivity.java   WebView kabuğu, ayar saklama, konum, sistem çubukları
  assets/www/
    index.html, style.css, app.js               arayüz
    engine.js                                   vakit ve kerahat hesabı (varsayılanlar DEFAULTS içinde)
    cities.js                                   81 il merkezi koordinatları
    fonts/                                      El Messiri ve Jost (SIL Open Font License 1.1, lisanslar klasörde)
  res/                                          simge, tema, renkler
```

Teknik notlar: minSdk 26, targetSdk/compileSdk 35, AGP 8.7.3, Gradle 8.9, JDK 17. Hiçbir dış bağımlılık (AndroidX, Kotlin vb.) kullanılmaz.
