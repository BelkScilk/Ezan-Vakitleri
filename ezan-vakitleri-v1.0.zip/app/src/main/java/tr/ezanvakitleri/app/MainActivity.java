package tr.ezanvakitleri.app;

import android.Manifest;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.util.Locale;

/**
 * Ezan Vakitleri: arayüz ve hesaplama assets/www içindeki HTML/CSS/JS'tir (internet gerekmez).
 * Bu sınıf yalnızca ince bir kabuktur: WebView'i açar, sistem çubuklarını temaya uydurur,
 * ayarları saklar ve konumu (yalnızca kullanıcı isterse) cihazdan alıp sayfaya iletir.
 */
public class MainActivity extends Activity {

    private static final String START_URL = "file:///android_asset/www/index.html";
    private static final String ASSET_PREFIX = "file:///android_asset/";
    private static final String PREFS = "ezan";
    private static final int REQ_LOCATION = 1001;

    // CSS'teki --bg değerleriyle aynı (sayfa boyanmadan önceki ilk kare için)
    private static final int BG_DARK = Color.parseColor("#0A1433");
    private static final int BG_LIGHT = Color.parseColor("#F1F5FB");

    private static final long FIX_TIMEOUT_MS = 15000L;          // taze konum için bekleme
    private static final long FRESH_MS = 15 * 60 * 1000L;       // bu kadar yeni son bilinen konum hemen kullanılır
    private static final long STALE_OK_MS = 24 * 60 * 60 * 1000L; // taze konum alınamazsa en çok bu kadar eski kayıt

    private final Handler main = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private WebView web;
    private SharedPreferences prefs;
    private boolean pendingInteractive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean dark = isNight();

        root = new FrameLayout(this);
        root.setBackgroundColor(bgFor(dark));
        // Android 15'te (targetSdk 35) uygulama ekranın tamamına çizilir: çubuk payını kendimiz bırakırız.
        // Eski sürümlerde (Android 14 ve öncesi) sistem payı kendisi bırakır, klavye için adjustResize yeter;
        // bu yüzden yalnızca zorunlu tam ekran çizimde (Android 15+) elle pay bırakılır.
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                if (Build.VERSION.SDK_INT < 35) { return insets; }
                Insets i = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                v.setPadding(i.left, i.top, i.right, i.bottom);
                return WindowInsets.CONSUMED;
            }
        });

        web = new WebView(this);
        web.setBackgroundColor(bgFor(dark));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        configure(web.getSettings());
        web.addJavascriptInterface(new Bridge(), "EzanAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Yalnızca uygulamanın kendi sayfaları açılır; dışarıya gidiş engellenir.
                return !request.getUrl().toString().startsWith(ASSET_PREFIX);
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        applyBars(dark, bgFor(dark));
        web.loadUrl(START_URL);
    }

    @SuppressWarnings("deprecation")
    private void configure(WebSettings s) {
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);                 // varlıklar (file:///android_asset) yine de açılır
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setGeolocationEnabled(false);              // konum, aşağıdaki köprü üzerinden alınır
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(textZoom());
        if (Build.VERSION.SDK_INT >= 33) {
            s.setAlgorithmicDarkeningAllowed(false); // sayfa kendi temasını yönetir
        } else if (Build.VERSION.SDK_INT >= 29) {
            s.setForceDark(WebSettings.FORCE_DARK_OFF);
        }
    }

    /** Sistem yazı boyutunu izler, ancak kadrandaki sayaç taşmasın diye 0,85 - 1,15 ile sınırlar. */
    private int textZoom() {
        float fs = getResources().getConfiguration().fontScale;
        return Math.round(100f * Math.max(0.85f, Math.min(1.15f, fs)));
    }

    private boolean isNight() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    private static int bgFor(boolean dark) { return dark ? BG_DARK : BG_LIGHT; }

    /** Pencere ve sistem çubukları: arka plan rengi ile simge (açık/koyu) takımı temaya uydurulur. */
    @SuppressWarnings("deprecation")
    private void applyBars(boolean dark, int bg) {
        Window w = getWindow();
        w.setBackgroundDrawable(new ColorDrawable(bg));
        if (root != null) { root.setBackgroundColor(bg); }
        if (web != null) { web.setBackgroundColor(bg); }
        if (Build.VERSION.SDK_INT < 35) {
            w.setStatusBarColor(bg);
            w.setNavigationBarColor(bg);
        }
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(dark ? 0 : mask, mask);
            }
        } else {
            View d = w.getDecorView();
            int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            int f = d.getSystemUiVisibility();
            d.setSystemUiVisibility(dark ? (f & ~light) : (f | light));
        }
    }

    /* ------------------------------------------------------------------ sayfa köprüsü */

    final class Bridge {
        @JavascriptInterface
        public String getPref(String key) { return prefs.getString(key, null); }

        @JavascriptInterface
        public void setPref(String key, String value) { prefs.edit().putString(key, value).apply(); }

        @JavascriptInterface
        public boolean isDark() { return isNight(); }

        @JavascriptInterface
        public void setTheme(final boolean dark, final String bgHex) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    int bg = bgFor(dark);
                    try { if (bgHex != null && bgHex.length() > 0) { bg = Color.parseColor(bgHex); } }
                    catch (IllegalArgumentException ignored) { /* varsayılan renk */ }
                    applyBars(dark, bg);
                }
            });
        }

        @JavascriptInterface
        public void requestLocation(final boolean interactive) {
            runOnUiThread(new Runnable() {
                @Override public void run() { startLocation(interactive); }
            });
        }
    }

    /* ------------------------------------------------------------------ konum */

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startLocation(boolean interactive) {
        if (hasLocationPermission()) { fetchLocation(interactive); return; }
        if (!interactive) { return; }                // sessiz yenileme izin istemez
        pendingInteractive = true;
        requestPermissions(new String[] {
                Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION }, REQ_LOCATION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_LOCATION) { return; }
        boolean interactive = pendingInteractive;
        pendingInteractive = false;
        boolean ok = false;
        for (int r : grantResults) { if (r == PackageManager.PERMISSION_GRANTED) { ok = true; } }
        if (ok) { fetchLocation(interactive); } else { emitError("denied", interactive); }
    }

    @SuppressWarnings("deprecation")
    private void fetchLocation(boolean interactive) {
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (lm == null) { emitError("unavailable", interactive); return; }

        boolean on;
        if (Build.VERSION.SDK_INT >= 28) { on = lm.isLocationEnabled(); }
        else { on = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER); }
        if (!on) { emitError("disabled", interactive); return; }

        Location best = null;
        String live = null;                          // taze konum için kullanılacak sağlayıcı
        String[] order = { LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER };
        for (String p : order) {
            try {
                if (!lm.isProviderEnabled(p)) { continue; }
                if (live == null && !LocationManager.PASSIVE_PROVIDER.equals(p)) { live = p; }
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) { best = l; }
            } catch (SecurityException | IllegalArgumentException ignored) { /* bu sağlayıcıyı atla */ }
        }

        long age = best == null ? Long.MAX_VALUE : System.currentTimeMillis() - best.getTime();
        Location usable = (best != null && age <= STALE_OK_MS) ? best : null;
        if (best != null && age <= FRESH_MS) { emitLocation(best, interactive); return; }
        if (live == null) {
            if (usable != null) { emitLocation(usable, interactive); } else { emitError("unavailable", interactive); }
            return;
        }
        requestFresh(lm, live, interactive, usable);
    }

    @SuppressWarnings("deprecation")
    private void requestFresh(final LocationManager lm, String provider, final boolean interactive, final Location fallback) {
        final boolean[] done = { false };
        final Runnable[] timeout = new Runnable[1];
        final LocationListener listener = new LocationListener() {
            @Override public void onLocationChanged(Location l) {
                if (done[0]) { return; }
                done[0] = true;
                main.removeCallbacks(timeout[0]);
                emitLocation(l, interactive);
            }
            @Override public void onProviderEnabled(String p) { }
            @Override public void onProviderDisabled(String p) { }
            @Override public void onStatusChanged(String p, int status, Bundle extras) { }
        };
        timeout[0] = new Runnable() {
            @Override public void run() {
                if (done[0]) { return; }
                done[0] = true;
                try { lm.removeUpdates(listener); } catch (SecurityException ignored) { /* yok say */ }
                if (fallback != null) { emitLocation(fallback, interactive); } else { emitError("timeout", interactive); }
            }
        };
        try {
            lm.requestSingleUpdate(provider, listener, Looper.getMainLooper());
            main.postDelayed(timeout[0], FIX_TIMEOUT_MS);
        } catch (SecurityException | IllegalArgumentException e) {
            if (fallback != null) { emitLocation(fallback, interactive); } else { emitError("unavailable", interactive); }
        }
    }

    private void emitLocation(Location l, boolean interactive) {
        js(String.format(Locale.US, "window.__onLocation&&window.__onLocation(%.5f,%.5f,%s)",
                l.getLatitude(), l.getLongitude(), interactive ? "true" : "false"));
    }

    private void emitError(String code, boolean interactive) {
        js("window.__onLocationError&&window.__onLocationError('" + code + "'," + (interactive ? "true" : "false") + ")");
    }

    private void js(String code) {
        if (web != null) { web.evaluateJavascript(code, null); }
    }

    /* ------------------------------------------------------------------ yaşam döngüsü */

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        boolean dark = (newConfig.uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        applyBars(dark, bgFor(dark));
        if (web != null) {
            web.getSettings().setTextZoom(textZoom());
            js("window.__onSystemTheme&&window.__onSystemTheme(" + (dark ? "true" : "false") + ")");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            js("window.__onResume&&window.__onResume()");
        }
    }

    @Override
    protected void onPause() {
        if (web != null) { web.onPause(); }
        super.onPause();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        // Açık bir alt sayfa varsa önce o kapanır; yoksa uygulamadan çıkılır.
        web.evaluateJavascript("(function(){return !!(window.__onBack&&window.__onBack());})()",
                new ValueCallback<String>() {
                    @Override public void onReceiveValue(String value) {
                        if (!"true".equals(value)) { MainActivity.super.onBackPressed(); }
                    }
                });
    }

    @Override
    protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        if (web != null) {
            root.removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
