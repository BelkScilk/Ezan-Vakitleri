/*!
 * Ezan Vakitleri - hesaplama motoru (internet gerektirmez)
 *
 * Güneşin konumu: NOAA / Meeus düşük duyarlıklı formülleri (saniye mertebesinde hata).
 * Yöntem: Diyanet İşleri Başkanlığı
 *   - İmsak: güneş ufkun 18° altında
 *   - Yatsı: güneş ufkun 17° altında
 *   - İkindi: gölge boyu = cismin boyu (cumhur hesabı)
 *   - Güneş / Akşam / Öğle / İkindi: Diyanet'in ihtiyat (temkin) payları (-7, +7, +5, +4 dk)
 *   - Güneşin sapması ve zaman denklemi günde bir kez, o günün 00:00 UT anı için alınır
 *     (Diyanet'in yayımladığı 300'ü aşkın vakit değerinin %96'sı dakikası dakikasına tutar,
 *      hiçbiri 1 dakikadan fazla sapmaz).
 *
 * Kerahat vakitleri (Hanefî): güneş doğarken, istiva (öğle) ve güneş batarken.
 * Süreler ayarlanabilir; varsayılanlar aşağıdadır.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) { module.exports = factory(); }
  else { root.EzanEngine = factory(); }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var RAD = Math.PI / 180;
  var DEG = 180 / Math.PI;
  var MIN = 60000;
  var HOUR = 3600000;
  var DAY = 86400000;

  var KEYS = ['imsak', 'gunes', 'ogle', 'ikindi', 'aksam', 'yatsi'];

  var DEFAULTS = {
    fajrAngle: 18,
    ishaAngle: 17,
    sunAltitude: -0.833,          // doğuş/batış: 34' kırılma + 16' güneş yarıçapı
    asrShadow: 1,                 // gölge = boy
    adjust: { imsak: 0, gunes: -7, ogle: 5, ikindi: 4, aksam: 7, yatsi: 0 },   // dakika
    bias: 0.08,                   // Diyanet çıktısına en iyi uyan küçük genel sapma (dk, ≈5 sn)
    rounding: 'round',            // dakikaya yuvarlama: round | floor | ceil
    kerahat: { sabah: 45, istiva: 10, aksam: 45 }                              // dakika
  };

  function pick(v, d) { return (v !== undefined && v !== null) ? v : d; }

  function merge(opt) {
    var o = opt || {};
    var k = o.kerahat || {};
    var a = o.adjust || {};
    return {
      fajrAngle: pick(o.fajrAngle, DEFAULTS.fajrAngle),
      ishaAngle: pick(o.ishaAngle, DEFAULTS.ishaAngle),
      sunAltitude: pick(o.sunAltitude, DEFAULTS.sunAltitude),
      asrShadow: pick(o.asrShadow, DEFAULTS.asrShadow),
      bias: pick(o.bias, DEFAULTS.bias),
      rounding: o.rounding || DEFAULTS.rounding,
      adjust: {
        imsak: pick(a.imsak, DEFAULTS.adjust.imsak),
        gunes: pick(a.gunes, DEFAULTS.adjust.gunes),
        ogle: pick(a.ogle, DEFAULTS.adjust.ogle),
        ikindi: pick(a.ikindi, DEFAULTS.adjust.ikindi),
        aksam: pick(a.aksam, DEFAULTS.adjust.aksam),
        yatsi: pick(a.yatsi, DEFAULTS.adjust.yatsi)
      },
      kerahat: {
        sabah: pick(k.sabah, DEFAULTS.kerahat.sabah),
        istiva: pick(k.istiva, DEFAULTS.kerahat.istiva),
        aksam: pick(k.aksam, DEFAULTS.kerahat.aksam)
      }
    };
  }

  function julianDay(ms) { return ms / DAY + 2440587.5; }

  /** Güneşin sapması (derece) ve zaman denklemi (dakika). */
  function solar(jd) {
    var T = (jd - 2451545.0) / 36525.0;
    var L0 = (280.46646 + T * (36000.76983 + T * 0.0003032)) % 360;
    if (L0 < 0) { L0 += 360; }
    var M = 357.52911 + T * (35999.05029 - 0.0001537 * T);
    var e = 0.016708634 - T * (0.000042037 + 0.0000001267 * T);
    var Mr = M * RAD;
    var C = Math.sin(Mr) * (1.914602 - T * (0.004817 + 0.000014 * T)) +
            Math.sin(2 * Mr) * (0.019993 - 0.000101 * T) +
            Math.sin(3 * Mr) * 0.000289;
    var trueLong = L0 + C;
    var omega = 125.04 - 1934.136 * T;
    var lambda = trueLong - 0.00569 - 0.00478 * Math.sin(omega * RAD);
    var eps0 = 23 + (26 + (21.448 - T * (46.815 + T * (0.00059 - T * 0.001813))) / 60) / 60;
    var eps = (eps0 + 0.00256 * Math.cos(omega * RAD)) * RAD;
    var dec = Math.asin(Math.sin(eps) * Math.sin(lambda * RAD)) * DEG;
    var y = Math.tan(eps / 2); y = y * y;
    var L0r = L0 * RAD;
    var eot = 4 * DEG * (y * Math.sin(2 * L0r) - 2 * e * Math.sin(Mr) +
              4 * e * y * Math.sin(Mr) * Math.cos(2 * L0r) -
              0.5 * y * y * Math.sin(4 * L0r) - 1.25 * e * e * Math.sin(2 * Mr));
    return { dec: dec, eot: eot };
  }

  function roundMinute(ms, mode) {
    var q = ms / MIN;
    if (mode === 'floor') { return Math.floor(q + 1e-9) * MIN; }
    if (mode === 'ceil') { return Math.ceil(q - 1e-9) * MIN; }
    return Math.round(q) * MIN;
  }

  /**
   * Bir takvim günü (yerel tarih) için vakitler.
   * y, m(1-12), d: yerel tarih; lat/lon: derece (doğu +); tzMin: UTC'ye göre dakika (Türkiye = 180).
   * Dönüş: { imsak, gunes, ogle, ikindi, aksam, yatsi } (UTC ms, dakikaya yuvarlanmış; hesaplanamazsa NaN)
   *        ve raw: ihtiyat payı eklenmemiş, yuvarlanmamış astronomik anlar.
   */
  function computeDay(y, m, d, lat, lon, tzMin, opt) {
    var o = merge(opt);
    var s = solar(julianDay(Date.UTC(y, m - 1, d, 0, 0, 0)));        // günlük sabitler: 00:00 UT
    var noonUtc = Date.UTC(y, m - 1, d, 12, 0, 0);

    var transit = noonUtc - (lon / 15) * HOUR - s.eot * MIN;

    // Yerel takvim gününe oturt (nadir: saat dilimi ile boylam çok farklıysa)
    var localMidnight = Date.UTC(y, m - 1, d);
    var localTransit = transit + tzMin * MIN;
    if (localTransit < localMidnight) { transit += DAY; }
    else if (localTransit >= localMidnight + DAY) { transit -= DAY; }

    var latR = lat * RAD;
    var decR = s.dec * RAD;

    function hourAngle(altDeg) {
      var c = (Math.sin(altDeg * RAD) - Math.sin(latR) * Math.sin(decR)) /
              (Math.cos(latR) * Math.cos(decR));
      if (!(c >= -1 && c <= 1)) { return NaN; }
      return (Math.acos(c) * DEG / 15) * HOUR;
    }

    var asrAlt = Math.atan(1 / (o.asrShadow + Math.tan(Math.abs(lat - s.dec) * RAD))) * DEG;

    var raw = {
      imsak: transit - hourAngle(-o.fajrAngle),
      gunes: transit - hourAngle(o.sunAltitude),
      ogle: transit,
      ikindi: transit + hourAngle(asrAlt),
      aksam: transit + hourAngle(o.sunAltitude),
      yatsi: transit + hourAngle(-o.ishaAngle)
    };

    var out = { raw: raw };
    for (var i = 0; i < KEYS.length; i++) {
      var k = KEYS[i];
      var v = raw[k];
      out[k] = isNaN(v) ? NaN : roundMinute(v + (o.adjust[k] + o.bias) * MIN, o.rounding);
    }
    return out;
  }

  /** Üç kerahat penceresi: [{id, start, end}] (ms). */
  function kerahatWindows(t, opt) {
    var k = merge(opt).kerahat;
    var list = [];
    if (!isNaN(t.gunes)) { list.push({ id: 'sabah', start: t.gunes, end: t.gunes + k.sabah * MIN }); }
    if (!isNaN(t.ogle)) { list.push({ id: 'istiva', start: t.ogle - k.istiva * MIN, end: t.ogle }); }
    if (!isNaN(t.aksam)) { list.push({ id: 'aksam', start: t.aksam - k.aksam * MIN, end: t.aksam }); }
    return list;
  }

  /**
   * Verilen anın tam durumu.
   *  loc: {lat, lon}; getTz(ms): o anda UTC'ye göre dakika farkı; opt: ayarlar
   */
  function snapshot(now, loc, getTz, opt) {
    var tz0 = getTz(now);
    var L = new Date(now + tz0 * MIN);
    var y = L.getUTCFullYear(), m = L.getUTCMonth() + 1, d = L.getUTCDate();

    var days = [];
    for (var k = -1; k <= 1; k++) {
      var c = new Date(Date.UTC(y, m - 1, d + k));
      var yy = c.getUTCFullYear(), mm = c.getUTCMonth() + 1, dd = c.getUTCDate();
      var tz = getTz(Date.UTC(yy, mm - 1, dd, 12) - tz0 * MIN);
      var t = computeDay(yy, mm, dd, loc.lat, loc.lon, tz, opt);
      t.date = { y: yy, m: mm, d: dd };
      t.kerahat = kerahatWindows(t, opt);
      days.push(t);
    }
    var today = days[1];

    // Vakit olayları (üç gün) zaman sırasıyla
    var events = [];
    days.forEach(function (day, i) {
      KEYS.forEach(function (key) {
        if (!isNaN(day[key])) { events.push({ key: key, at: day[key], day: i - 1 }); }
      });
    });
    events.sort(function (a, b) { return a.at - b.at; });
    var current = null, next = null;
    for (var i = 0; i < events.length; i++) {
      if (events[i].at <= now) { current = events[i]; }
      else if (!next) { next = events[i]; }
    }

    // Kerahat pencereleri (üç gün)
    var wins = [];
    days.forEach(function (day, i) {
      day.kerahat.forEach(function (w) { wins.push({ id: w.id, start: w.start, end: w.end, day: i - 1 }); });
    });
    wins.sort(function (a, b) { return a.start - b.start; });
    var active = null, upcoming = null, previous = null;
    for (var j = 0; j < wins.length; j++) {
      var w = wins[j];
      if (w.start <= now && now < w.end) { active = w; }
      else if (w.end <= now) { previous = w; }
      else if (w.start > now && !upcoming) { upcoming = w; }
    }

    var kerahat;
    if (active) {
      kerahat = {
        active: true, window: active,
        remaining: active.end - now,            // kerahatın bitmesine
        total: active.end - active.start,
        elapsed: now - active.start
      };
    } else {
      var from = previous ? previous.end : (upcoming ? upcoming.start - DAY / 2 : now);
      kerahat = {
        active: false, window: upcoming,
        remaining: upcoming ? upcoming.start - now : NaN,   // kerahatın başlamasına
        total: upcoming ? upcoming.start - from : NaN,
        elapsed: now - from
      };
    }

    var vakit = {
      current: current, next: next,
      remaining: next ? next.at - now : NaN,
      total: (next && current) ? next.at - current.at : NaN,
      elapsed: current ? now - current.at : NaN
    };

    return { now: now, tz: tz0, date: today.date, today: today, days: days, vakit: vakit, kerahat: kerahat };
  }

  return {
    KEYS: KEYS,
    DEFAULTS: DEFAULTS,
    solar: solar,
    julianDay: julianDay,
    computeDay: computeDay,
    kerahatWindows: kerahatWindows,
    snapshot: snapshot,
    merge: merge
  };
});
