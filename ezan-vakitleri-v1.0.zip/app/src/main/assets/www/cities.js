/*! 81 il merkezi (enlem, boylam). Vakit hesabı bu koordinatlarla yapılır. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) { module.exports = factory(); }
  else { root.EzanCities = factory(); }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // [ad, enlem, boylam]
  var RAW = [
    ['Adana', 37.0000, 35.3213], ['Adıyaman', 37.7648, 38.2786], ['Afyonkarahisar', 38.7507, 30.5567],
    ['Ağrı', 39.7191, 43.0503], ['Aksaray', 38.3687, 34.0370], ['Amasya', 40.6499, 35.8353],
    ['Ankara', 39.9334, 32.8597], ['Antalya', 36.8969, 30.7133], ['Ardahan', 41.1105, 42.7022],
    ['Artvin', 41.1828, 41.8183], ['Aydın', 37.8560, 27.8416], ['Balıkesir', 39.6484, 27.8826],
    ['Bartın', 41.6344, 32.3375], ['Batman', 37.8812, 41.1351], ['Bayburt', 40.2552, 40.2249],
    ['Bilecik', 40.1501, 29.9831], ['Bingöl', 38.8855, 40.4980], ['Bitlis', 38.4006, 42.1095],
    ['Bolu', 40.7392, 31.6089], ['Burdur', 37.7203, 30.2908], ['Bursa', 40.1826, 29.0665],
    ['Çanakkale', 40.1553, 26.4142], ['Çankırı', 40.6013, 33.6134], ['Çorum', 40.5506, 34.9556],
    ['Denizli', 37.7765, 29.0864], ['Diyarbakır', 37.9144, 40.2306], ['Düzce', 40.8438, 31.1565],
    ['Edirne', 41.6818, 26.5623], ['Elazığ', 38.6810, 39.2264], ['Erzincan', 39.7500, 39.5000],
    ['Erzurum', 39.9000, 41.2700], ['Eskişehir', 39.7767, 30.5206], ['Gaziantep', 37.0662, 37.3833],
    ['Giresun', 40.9128, 38.3895], ['Gümüşhane', 40.4603, 39.4814], ['Hakkari', 37.5744, 43.7408],
    ['Hatay', 36.2021, 36.1603], ['Iğdır', 39.9237, 44.0450], ['Isparta', 37.7648, 30.5566],
    ['İstanbul', 41.0082, 28.9784], ['İzmir', 38.4237, 27.1428], ['Kahramanmaraş', 37.5858, 36.9371],
    ['Karabük', 41.2061, 32.6204], ['Karaman', 37.1759, 33.2287], ['Kars', 40.6013, 43.0975],
    ['Kastamonu', 41.3887, 33.7827], ['Kayseri', 38.7312, 35.4787], ['Kilis', 36.7184, 37.1212],
    ['Kırıkkale', 39.8468, 33.5153], ['Kırklareli', 41.7333, 27.2167], ['Kırşehir', 39.1425, 34.1709],
    ['Kocaeli', 40.7654, 29.9408], ['Konya', 37.8667, 32.4833], ['Kütahya', 39.4167, 29.9833],
    ['Malatya', 38.3552, 38.3095], ['Manisa', 38.6191, 27.4289], ['Mardin', 37.3212, 40.7245],
    ['Mersin', 36.8000, 34.6333], ['Muğla', 37.2153, 28.3636], ['Muş', 38.9462, 41.7539],
    ['Nevşehir', 38.6939, 34.6857], ['Niğde', 37.9667, 34.6833], ['Ordu', 40.9839, 37.8764],
    ['Osmaniye', 37.0742, 36.2478], ['Rize', 41.0201, 40.5234], ['Sakarya', 40.7889, 30.4053],
    ['Samsun', 41.2867, 36.3300], ['Siirt', 37.9333, 41.9500], ['Sinop', 42.0231, 35.1531],
    ['Sivas', 39.7477, 37.0179], ['Şanlıurfa', 37.1591, 38.7969], ['Şırnak', 37.5164, 42.4611],
    ['Tekirdağ', 40.9833, 27.5167], ['Tokat', 40.3167, 36.5500], ['Trabzon', 41.0027, 39.7168],
    ['Tunceli', 39.1079, 39.5401], ['Uşak', 38.6823, 29.4082], ['Van', 38.4891, 43.4089],
    ['Yalova', 40.6500, 29.2667], ['Yozgat', 39.8181, 34.8147], ['Zonguldak', 41.4564, 31.7987]
  ];

  var list = RAW.map(function (r) { return { name: r[0], lat: r[1], lon: r[2] }; });
  list.sort(function (a, b) { return a.name.localeCompare(b.name, 'tr'); });

  function nearest(lat, lon) {
    var best = null, bd = Infinity;
    for (var i = 0; i < list.length; i++) {
      var dLat = (list[i].lat - lat) * Math.PI / 180;
      var dLon = (list[i].lon - lon) * Math.PI / 180;
      var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat * Math.PI / 180) * Math.cos(list[i].lat * Math.PI / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
      var d = 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      if (d < bd) { bd = d; best = list[i]; }
    }
    return { city: best, km: bd };
  }

  function find(name) {
    for (var i = 0; i < list.length; i++) { if (list[i].name === name) { return list[i]; } }
    return null;
  }

  return { list: list, nearest: nearest, find: find };
});
