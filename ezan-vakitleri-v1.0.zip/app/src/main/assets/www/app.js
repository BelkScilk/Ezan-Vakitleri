/* Ezan Vakitleri - arayüz ve uygulama mantığı
   Hesaplama: engine.js (internet gerekmez). Android köprüsü: window.EzanAndroid (yoksa tarayıcı yedekleri kullanılır). */
(function () {
  'use strict';

  var E = window.EzanEngine;
  var C = window.EzanCities;
  var A = window.EzanAndroid || null;
  var MIN = 60000;

  var VAKIT = { imsak: 'İmsak', gunes: 'Güneş', ogle: 'Öğle', ikindi: 'İkindi', aksam: 'Akşam', yatsi: 'Yatsı' };
  var KERAHAT = { sabah: 'Güneş doğarken', istiva: 'İstiva', aksam: 'Güneş batarken' };
  var KERAHAT_KEYS = ['sabah', 'istiva', 'aksam'];
  var MONTHS = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
  var WEEKDAYS = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
  var LIMITS = { sabah: [20, 60], istiva: [5, 20], aksam: [20, 60] };
  var STEP = 5;
  var GEO_LABEL_KM = 200;          // en yakın il bundan uzaksa "Konumum" yazılır
  var GEO_SILENT_KM = 5;           // sessiz yenilemede bundan az yer değiştirdiyse dokunma

  var GEO_MESSAGES = {
    denied: 'Konum izni verilmedi. Listeden bir il seçebilir ya da izni uygulama ayarlarından açabilirsiniz.',
    disabled: 'Cihazın konum özelliği kapalı. Konumu açın ya da listeden bir il seçin.',
    timeout: 'Konum alınamadı. Birazdan yeniden deneyin ya da listeden bir il seçin.',
    unavailable: 'Konum bu cihazdan alınamıyor. Listeden bir il seçin.'
  };

  /* ------------------------------------------------------------------ yardımcılar */
  function $(id) { return document.getElementById(id); }
  function pad(n) { return n < 10 ? '0' + n : String(n); }
  function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }
  function f2(n) { return Math.round(n * 100) / 100; }
  function lowerTr(s) { return s.toLocaleLowerCase('tr'); }

  /** Arama için: büyük/küçük harf, i/ı ve Türkçe karakterler fark etmesin. */
  function fold(s) {
    return String(s).replace(/İ/g, 'i').replace(/I/g, 'i').replace(/ı/g, 'i')
      .toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  }

  function haversine(lat1, lon1, lat2, lon2) {
    var r = Math.PI / 180;
    var dLat = (lat2 - lat1) * r, dLon = (lon2 - lon1) * r;
    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  /** UTC ms -> verilen saat dilimindeki "SS:DD" */
  function hm(ms, tz) {
    if (!isFinite(ms)) { return '--:--'; }
    var d = new Date(ms + tz * MIN);
    return pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes());
  }
  /** Yerel gün başından beri geçen dakika (kesirli) */
  function localMinutes(ms, tz) {
    var d = new Date(ms + tz * MIN);
    return d.getUTCHours() * 60 + d.getUTCMinutes() + d.getUTCSeconds() / 60 + d.getUTCMilliseconds() / 60000;
  }
  function dateText(d) {
    var wd = new Date(Date.UTC(d.y, d.m - 1, d.d)).getUTCDay();
    return d.d + ' ' + MONTHS[d.m - 1] + ' ' + d.y + ', ' + WEEKDAYS[wd];
  }
  function durationWords(ms) {
    var m = Math.floor(ms / MIN);
    if (m < 1) { return '1 dakikadan az'; }
    var h = Math.floor(m / 60), r = m % 60;
    if (h && r) { return h + ' saat ' + r + ' dakika'; }
    return h ? h + ' saat' : r + ' dakika';
  }

  /* ------------------------------------------------------------------ kalıcı ayarlar */
  var store = {
    get: function (k) {
      try { if (A && A.getPref) { return A.getPref(k); } } catch (e) { /* yedeğe düş */ }
      try { return window.localStorage.getItem(k); } catch (e2) { return null; }
    },
    set: function (k, v) {
      try { if (A && A.setPref) { A.setPref(k, v); return; } } catch (e) { /* yedeğe düş */ }
      try { window.localStorage.setItem(k, v); } catch (e2) { /* yok say */ }
    }
  };

  function defaults() {
    return { mode: 'city', city: 'İstanbul', lat: 41.0082, lon: 28.9784, seen: false,
             kerahat: { sabah: E.DEFAULTS.kerahat.sabah, istiva: E.DEFAULTS.kerahat.istiva, aksam: E.DEFAULTS.kerahat.aksam } };
  }
  function loadState() {
    var s = defaults();
    try {
      var raw = store.get('state');
      var p = raw ? JSON.parse(raw) : null;
      if (p && typeof p === 'object') {
        if (typeof p.city === 'string' && C.find(p.city)) { s.city = p.city; }
        if (p.mode === 'gps' && isFinite(p.lat) && isFinite(p.lon) && Math.abs(p.lat) <= 90 && Math.abs(p.lon) <= 180) {
          s.mode = 'gps'; s.lat = +p.lat; s.lon = +p.lon;
        }
        KERAHAT_KEYS.forEach(function (k) {
          var v = p.kerahat ? +p.kerahat[k] : NaN;
          if (isFinite(v)) { s.kerahat[k] = clamp(Math.round(v / STEP) * STEP, LIMITS[k][0], LIMITS[k][1]); }
        });
        s.seen = !!p.seen;
      }
    } catch (e) { /* bozuk kayıt: varsayılanlar */ }
    return s;
  }
  var state = loadState();
  function saveState() { store.set('state', JSON.stringify(state)); }

  /* ------------------------------------------------------------------ zaman kaynağı */
  // Deneme için: index.html?now=2026-11-24T16:30 (+03:00 varsayılır) [&freeze=1]
  var clockOffset = 0, frozenAt = null;
  (function () {
    var m = /[?&]now=([^&]+)/.exec(window.location.search);
    if (!m) { return; }
    var v = decodeURIComponent(m[1]);
    if (!/(Z|[+-]\d\d:?\d\d)$/i.test(v)) { v += '+03:00'; }
    var t = Date.parse(v);
    if (isFinite(t)) {
      clockOffset = t - Date.now();
      if (/[?&]freeze=1/.test(window.location.search)) { frozenAt = t; }
    }
  })();
  function now() { return frozenAt !== null ? frozenAt : Date.now() + clockOffset; }

  /* ------------------------------------------------------------------ konum, saat dilimi, ayarlar */
  function loc() {
    if (state.mode === 'gps') { return { lat: state.lat, lon: state.lon }; }
    var c = C.find(state.city) || C.find('İstanbul');
    return { lat: c.lat, lon: c.lon };
  }
  // İller Türkiye saatindedir (UTC+3, yıl boyu). Konum modunda cihazın saat dilimi kullanılır.
  function tzOf(ms) { return state.mode === 'gps' ? -new Date(ms).getTimezoneOffset() : 180; }
  function opts() { return { kerahat: state.kerahat }; }

  /* ------------------------------------------------------------------ tema (sistemi izler) */
  var root = document.documentElement;
  var themeMeta = document.querySelector('meta[name="theme-color"]');
  function systemDark() {
    try { if (A && A.isDark) { return !!A.isDark(); } } catch (e) { /* yedeğe düş */ }
    return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  }
  function applyTheme(dark) {
    root.setAttribute('data-theme', dark ? 'dark' : 'light');
    var bg = window.getComputedStyle(root).getPropertyValue('--bg').trim();
    if (themeMeta && bg) { themeMeta.setAttribute('content', bg); }
    try { if (A && A.setTheme) { A.setTheme(dark, bg); } } catch (e) { /* yok say */ }
  }
  if (window.matchMedia) {
    var mq = window.matchMedia('(prefers-color-scheme: dark)');
    var onMq = function () { if (!A) { applyTheme(mq.matches); } };
    if (mq.addEventListener) { mq.addEventListener('change', onMq); } else if (mq.addListener) { mq.addListener(onMq); }
  }

  /* ------------------------------------------------------------------ rakam hücreli sayaç */
  function makeClock(el) {
    el.innerHTML = '<span class="g"><i></i><i></i></span><b>:</b><span class="g"><i></i><i></i></span><b>:</b><span class="g"><i></i><i></i></span>';
    el._cells = Array.prototype.slice.call(el.getElementsByTagName('i'));
    el._hours = el.firstChild;
    el._v = '';
  }
  function setClock(el, ms) {
    var str;
    if (!isFinite(ms)) { str = '------'; }
    else {
      var t = Math.max(0, Math.ceil(ms / 1000));
      var h = Math.min(99, Math.floor(t / 3600));
      str = pad(h) + pad(Math.floor(t / 60) % 60) + pad(t % 60);
    }
    if (str === el._v) { return; }
    el._v = str;
    for (var i = 0; i < 6; i++) { el._cells[i].textContent = str.charAt(i) === '-' ? '–' : str.charAt(i); }
    if (str.slice(0, 2) === '00') { el._hours.classList.add('zero'); } else { el._hours.classList.remove('zero'); }
  }

  /* ------------------------------------------------------------------ kadran (SVG) */
  var CX = 180, CY = 180, R = 150;
  function polar(r, deg) {
    var a = deg * Math.PI / 180;
    return [CX + r * Math.sin(a), CY - r * Math.cos(a)];
  }
  function arcPath(r, a1, a2) {
    if (a2 < a1) { a2 += 360; }
    var p1 = polar(r, a1), p2 = polar(r, a2);
    return 'M' + f2(p1[0]) + ' ' + f2(p1[1]) + 'A' + r + ' ' + r + ' 0 ' + ((a2 - a1) > 180 ? 1 : 0) + ' 1 ' + f2(p2[0]) + ' ' + f2(p2[1]);
  }
  // Öğle tepede, gece yarısı altta; dakika başına 0,25°
  function angleOf(ms, tz) { return (localMinutes(ms, tz) - 720) / 4; }

  function dialMarkup(s) {
    var T = s.today, out = [];
    out.push('<defs>' +
      '<radialGradient id="sunGlow"><stop offset="0" class="glow-sun" stop-opacity=".6"/><stop offset="1" class="glow-sun" stop-opacity="0"/></radialGradient>' +
      '<radialGradient id="moonGlow"><stop offset="0" class="glow-moon" stop-opacity=".45"/><stop offset="1" class="glow-moon" stop-opacity="0"/></radialGradient>' +
      '<mask id="moonMask" maskUnits="userSpaceOnUse" x="-16" y="-16" width="32" height="32"><rect x="-16" y="-16" width="32" height="32" fill="#fff"/><circle cx="5.4" cy="-3.8" r="8.6" fill="#000"/></mask>' +
      '</defs>');
    out.push('<circle class="d-track" cx="180" cy="180" r="' + R + '"/>');
    if (isFinite(T.gunes) && isFinite(T.aksam)) {
      out.push('<path class="d-day" d="' + arcPath(R, angleOf(T.gunes, tzOf(T.gunes)), angleOf(T.aksam, tzOf(T.aksam))) + '"/>');
    }
    T.kerahat.forEach(function (w) {
      out.push('<path class="d-ker" data-id="' + w.id + '" d="' + arcPath(R, angleOf(w.start, tzOf(w.start)), angleOf(w.end, tzOf(w.end))) + '"/>');
    });
    out.push('<circle class="d-itrack" cx="180" cy="180" r="124"/>');
    out.push('<circle id="dProg" class="d-prog" cx="180" cy="180" r="124" pathLength="100" transform="rotate(-90 180 180)"/>');
    out.push('<g id="dSun" class="d-sun"><g transform="translate(180 ' + (CY - R) + ')">' +
      '<circle id="dGlow" r="28" fill="url(#sunGlow)"/>' +
      '<circle class="d-sundisc" r="10.5"/>' +
      '<circle class="d-moon" r="10" mask="url(#moonMask)"/></g></g>');
    return out.join('');
  }

  /* ------------------------------------------------------------------ DOM başvuruları */
  var dialEl = $('dial'), svgEl = $('dialSvg'), railEl = $('rail');
  var dialLabelEl = $('dialLabel'), dialTimeEl = $('dialTime'), dialSubEl = $('dialSub'), dialSrEl = $('dialSr');
  var nextNameEl = $('nextName'), nextCountEl = $('nextCount'), nextBarEl = $('nextBar');
  var cityBtn = $('cityBtn'), cityNameEl = $('cityName'), dateEl = $('dateText');
  var sunEl, progEl, glowEl, kerEls = [];
  var railMeta = [];
  var dialSig = '', dialPhase = '', nextSig = '', srSig = '', lastKey = '', firstPaint = true;

  /* ------------------------------------------------------------------ yeniden kurulum (gün, konum veya ayar değişince) */
  function rebuildKey(s) {
    var l = loc(), k = state.kerahat;
    return [s.date.y, s.date.m, s.date.d, state.mode, l.lat, l.lon, k.sabah, k.istiva, k.aksam, s.tz].join('|');
  }

  function buildRail(s) {
    var T = s.today, items = [];
    E.KEYS.forEach(function (key) { if (isFinite(T[key])) { items.push({ type: 'v', key: key, at: T[key] }); } });
    T.kerahat.forEach(function (w) { items.push({ type: 'k', key: w.id, at: w.start, end: w.end }); });
    items.sort(function (a, b) { return (a.at - b.at) || (a.type === b.type ? 0 : (a.type === 'v' ? -1 : 1)); });
    var html = '';
    items.forEach(function (it) {
      if (it.type === 'v') {
        html += '<li class="v"><span class="nm">' + VAKIT[it.key] + '</span><span class="tm">' + hm(it.at, tzOf(it.at)) + '</span></li>';
      } else {
        html += '<li class="k"><span class="nm">' + KERAHAT[it.key] + '<small>Kerahat vakti, ' + Math.round((it.end - it.at) / MIN) + ' dk</small></span>' +
                '<span class="tm">' + hm(it.at, tzOf(it.at)) + '–' + hm(it.end, tzOf(it.end)) + '</span></li>';
      }
    });
    railEl.innerHTML = html;
    var lis = railEl.children;
    railMeta = items.map(function (it, i) { it.el = lis[i]; it.cls = it.type; return it; });
  }

  function updateCityLabel() {
    var geo = state.mode === 'gps', name = state.city;
    if (geo) {
      var n = C.nearest(state.lat, state.lon);
      name = n.km <= GEO_LABEL_KM ? n.city.name : 'Konumum';
    }
    cityNameEl.textContent = name;
    if (geo) { cityBtn.classList.add('is-geo'); } else { cityBtn.classList.remove('is-geo'); }
    cityBtn.setAttribute('aria-label', 'Konum: ' + name + '. Değiştirmek için dokunun');
    var items = cityListEl.getElementsByClassName('city-item');
    for (var i = 0; i < items.length; i++) {
      if (!geo && items[i].getAttribute('data-name') === state.city) { items[i].setAttribute('aria-current', 'true'); }
      else { items[i].removeAttribute('aria-current'); }
    }
  }

  function rebuild(s) {
    svgEl.innerHTML = dialMarkup(s);
    sunEl = $('dSun'); progEl = $('dProg'); glowEl = $('dGlow');
    kerEls = Array.prototype.slice.call(svgEl.getElementsByClassName('d-ker'));
    buildRail(s);
    dateEl.textContent = dateText(s.date);
    updateCityLabel();
    dialSig = ''; dialPhase = ''; nextSig = ''; srSig = '';
    if (firstPaint) {
      // açılışta tek bir hareket: güneş öğleden bugünkü yerine süzülür, halka dolar
      firstPaint = false;
      sunEl.style.transform = 'rotate(0deg)';
      progEl.style.strokeDasharray = '0 100';
      void svgEl.getBoundingClientRect();
      svgEl.classList.add('intro');
      window.setTimeout(function () { svgEl.classList.remove('intro'); }, 1500);
    }
  }

  /* ------------------------------------------------------------------ saniyelik güncellemeler */
  function updateDial(s) {
    var T = s.today, k = s.kerahat, w = k.window;
    var hasDay = isFinite(T.gunes) && isFinite(T.aksam);
    var phase = (!hasDay || (s.now >= T.gunes && s.now < T.aksam)) ? 'day' : 'night';
    if (phase !== dialPhase) {
      dialPhase = phase;
      dialEl.setAttribute('data-phase', phase);
      glowEl.setAttribute('fill', 'url(#' + (phase === 'day' ? 'sunGlow' : 'moonGlow') + ')');
    }
    sunEl.style.transform = 'rotate(' + f2((localMinutes(s.now, s.tz) - 720) / 4) + 'deg)';

    var frac = (w && k.total > 0) ? clamp(k.remaining / k.total, 0, 1) : 0;
    progEl.style.strokeDasharray = f2(frac * 100) + ' 100';
    progEl.style.opacity = frac > 0 ? '1' : '0';

    var sig = (k.active ? 'a' : 'w') + (w ? w.id + w.day : '-');
    if (sig !== dialSig) {
      dialSig = sig;
      dialEl.setAttribute('data-state', k.active ? 'active' : 'wait');
      dialLabelEl.textContent = k.active ? 'Kerahat vaktinin bitmesine kalan' : 'Kerahat vaktine kalan';
      if (w) {
        var nm = w.day > 0 ? 'Yarın ' + lowerTr(KERAHAT[w.id]) : KERAHAT[w.id];
        dialSubEl.innerHTML = '<span class="nm">' + nm + '</span><span class="rg">' +
          hm(w.start, tzOf(w.start)) + '–' + hm(w.end, tzOf(w.end)) + '</span>';
      } else { dialSubEl.innerHTML = ''; }
      kerEls.forEach(function (el) {
        var on = k.active && w.day === 0 && el.getAttribute('data-id') === w.id;
        if (on) { el.classList.add('is-on'); } else { el.classList.remove('is-on'); }
      });
    }
    setClock(dialTimeEl, w ? k.remaining : NaN);

    // ekran okuyucu metni dakikada bir güncellenir
    var srKey = sig + '|' + (w ? Math.floor(k.remaining / MIN) : '-');
    if (srKey !== srSig) {
      srSig = srKey;
      var txt;
      if (!w) { txt = 'Kerahat vakti hesaplanamadı.'; }
      else if (k.active) { txt = 'Şu an kerahat vakti, ' + lowerTr(KERAHAT[w.id]) + '. Bitmesine ' + durationWords(k.remaining) + ' kaldı.'; }
      else { txt = 'Kerahat vaktine ' + durationWords(k.remaining) + ' kaldı. ' + (w.day > 0 ? 'Yarın ' + lowerTr(KERAHAT[w.id]) : KERAHAT[w.id]) +
             ', ' + hm(w.start, tzOf(w.start)) + ' ile ' + hm(w.end, tzOf(w.end)) + ' arası.'; }
      dialSrEl.textContent = txt;
    }
  }

  function updateRail(s) {
    var v = s.vakit, k = s.kerahat, t = s.now;
    var curKey = (v.current && v.current.day === 0) ? v.current.key : null;
    var nextKey = (v.next && v.next.day === 0) ? v.next.key : null;
    var actId = (k.active && k.window.day === 0) ? k.window.id : null;
    railMeta.forEach(function (it) {
      var c;
      if (it.type === 'v') {
        c = it.key === curKey ? 'v is-now' : (it.at <= t ? 'v is-past' : (it.key === nextKey ? 'v is-next' : 'v'));
      } else {
        c = it.key === actId ? 'k is-active' : (it.end <= t ? 'k is-past' : 'k');
      }
      if (c !== it.cls) { it.cls = c; it.el.className = c; }
    });
  }

  function updateNext(s) {
    var v = s.vakit;
    if (!v.next) { setClock(nextCountEl, NaN); return; }
    var sig = v.next.key + v.next.day;
    if (sig !== nextSig) {
      nextSig = sig;
      nextNameEl.innerHTML = '<span class="nm">' + VAKIT[v.next.key] + '</span><span class="at">' +
        hm(v.next.at, tzOf(v.next.at)) + (v.next.day > 0 ? ' yarın' : '') + '</span>';
    }
    setClock(nextCountEl, v.remaining);
    var p = v.total > 0 ? clamp(v.elapsed / v.total, 0, 1) : 0;
    nextBarEl.style.setProperty('--p', p.toFixed(4));
  }

  function render(t) {
    var s = E.snapshot(t, loc(), tzOf, opts());
    var key = rebuildKey(s);
    if (key !== lastKey) { lastKey = key; rebuild(s); }
    updateDial(s);
    updateRail(s);
    updateNext(s);
  }

  var timer = 0;
  function tick() {
    window.clearTimeout(timer);
    var t = now();
    render(t);
    timer = window.setTimeout(tick, 1000 - (t % 1000) + 8);    // bir sonraki saniye başına hizala
  }

  /* ------------------------------------------------------------------ alt sayfalar */
  var appEl = $('app'), scrimEl = $('scrim');
  var cityListEl = $('cityList'), cityQueryEl = $('cityQuery'), geoBtn = $('geoBtn'), geoMsgEl = $('geoMsg');
  var current = null, lastFocus = null, hideTimer = 0, pendingHide = null;
  var REDUCED = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  function finishHide() {
    if (!pendingHide) { return; }
    window.clearTimeout(hideTimer);
    var fn = pendingHide; pendingHide = null; fn();
  }

  function openSheet(name, firstRun) {
    if (current) { return; }
    finishHide();
    var sh = $(name === 'city' ? 'citySheet' : 'settingsSheet');
    lastFocus = document.activeElement;
    if (name === 'city') { prepareCitySheet(firstRun); } else { syncSettings(); }
    sh.hidden = false; scrimEl.hidden = false;
    void sh.offsetHeight;
    sh.classList.add('open'); scrimEl.classList.add('open');
    document.body.classList.add('lock');
    if ('inert' in appEl) { appEl.inert = true; }
    sh.setAttribute('tabindex', '-1');
    try { sh.focus({ preventScroll: true }); } catch (e) { sh.focus(); }
    current = sh;
    if (name === 'city' && !firstRun) {
      var sel = cityListEl.querySelector('[aria-current="true"]');
      if (sel && sel.scrollIntoView) { sel.scrollIntoView({ block: 'center' }); }
    }
  }

  function closeSheet() {
    if (!current) { return false; }
    var sh = current; current = null;
    sh.classList.remove('open'); scrimEl.classList.remove('open');
    document.body.classList.remove('lock');
    if ('inert' in appEl) { appEl.inert = false; }
    if (document.activeElement && document.activeElement.blur) { document.activeElement.blur(); }
    pendingHide = function () { sh.hidden = true; scrimEl.hidden = true; };
    hideTimer = window.setTimeout(finishHide, REDUCED ? 0 : 340);
    if (lastFocus && lastFocus.focus) { try { lastFocus.focus({ preventScroll: true }); } catch (e) { /* yok say */ } }
    return true;
  }

  function focusables(sh) {
    var list = sh.querySelectorAll('button, input, [tabindex]:not([tabindex="-1"])');
    return Array.prototype.filter.call(list, function (el) { return !el.disabled && el.offsetParent !== null; });
  }

  /* ------------------------------------------------------------------ il listesi ve konum */
  function buildCityList() {
    var html = '';
    C.list.forEach(function (c) {
      html += '<li data-f="' + fold(c.name) + '"><button type="button" class="city-item" data-name="' + c.name + '">' + c.name + '</button></li>';
    });
    html += '<li class="city-empty" hidden>Eşleşen il yok.</li>';
    cityListEl.innerHTML = html;
  }

  function filterCities() {
    var q = fold(cityQueryEl.value.trim()), any = false, empty = null;
    Array.prototype.forEach.call(cityListEl.children, function (li) {
      if (li.className === 'city-empty') { empty = li; return; }
      var show = !q || li.getAttribute('data-f').indexOf(q) !== -1;
      li.hidden = !show;
      if (show) { any = true; }
    });
    if (empty) { empty.hidden = any; }
  }

  function setGeoMsg(text, isErr) {
    geoMsgEl.textContent = text || '';
    if (isErr) { geoMsgEl.classList.add('err'); } else { geoMsgEl.classList.remove('err'); }
  }
  var geoBusyNow = false, geoTimer = 0;
  function geoBusy(b) {
    geoBusyNow = b;
    geoBtn.disabled = b;
    if (b) { geoBtn.classList.add('busy'); setGeoMsg('Konum alınıyor'); }
    else { geoBtn.classList.remove('busy'); }
  }

  function prepareCitySheet(firstRun) {
    cityQueryEl.value = '';
    filterCities();
    geoBusy(false);
    if (firstRun) { setGeoMsg('Vakitler için bir il seçin ya da konumunuzu kullanın. Konumunuz cihazdan çıkmaz.'); }
    else if (state.mode === 'gps') {
      var n = C.nearest(state.lat, state.lon);
      setGeoMsg('Konumunuz kullanılıyor' + (n.km <= GEO_LABEL_KM ? ' (en yakın il: ' + n.city.name + ').' : '.'));
    } else { setGeoMsg(''); }
  }

  function selectCity(name) {
    if (!C.find(name)) { return; }
    state.mode = 'city'; state.city = name; state.seen = true;
    saveState();
    closeSheet();
    tick();
  }

  function onLocation(lat, lon, interactive) {
    window.clearTimeout(geoTimer);
    if (interactive) { geoBusy(false); }
    lat = +lat; lon = +lon;
    if (!isFinite(lat) || !isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) { onLocationError('unavailable', interactive); return; }
    if (!interactive && state.mode === 'gps' && haversine(state.lat, state.lon, lat, lon) < GEO_SILENT_KM) { return; }
    if (!interactive && state.mode !== 'gps') { return; }     // sessiz yenileme yalnızca konum modundayken
    state.mode = 'gps'; state.lat = Math.round(lat * 1e4) / 1e4; state.lon = Math.round(lon * 1e4) / 1e4; state.seen = true;
    saveState();
    if (interactive) { closeSheet(); }
    tick();
  }

  function onLocationError(code, interactive) {
    window.clearTimeout(geoTimer);
    if (!interactive) { return; }
    geoBusy(false);
    setGeoMsg(GEO_MESSAGES[code] || GEO_MESSAGES.unavailable, true);
  }

  function requestGeo(interactive) {
    if (interactive && geoBusyNow) { return; }
    if (interactive) {
      geoBusy(true);
      window.clearTimeout(geoTimer);
      geoTimer = window.setTimeout(function () { onLocationError('timeout', true); }, 30000);
    }
    if (A && A.requestLocation) {
      try { A.requestLocation(!!interactive); } catch (e) { onLocationError('unavailable', interactive); }
      return;
    }
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        function (p) { onLocation(p.coords.latitude, p.coords.longitude, interactive); },
        function (err) { onLocationError(err && err.code === 1 ? 'denied' : (err && err.code === 3 ? 'timeout' : 'unavailable'), interactive); },
        { enableHighAccuracy: false, timeout: 20000, maximumAge: 600000 });
      return;
    }
    onLocationError('unavailable', interactive);
  }

  /* ------------------------------------------------------------------ kerahat süreleri ayarı */
  function syncSettings() {
    var rows = document.querySelectorAll('.stepper');
    Array.prototype.forEach.call(rows, function (row) {
      var k = row.getAttribute('data-k'), v = state.kerahat[k];
      var btns = row.getElementsByTagName('button');
      row.getElementsByTagName('output')[0].textContent = v + ' dk';
      btns[0].disabled = v <= LIMITS[k][0];
      btns[1].disabled = v >= LIMITS[k][1];
    });
  }

  /* ------------------------------------------------------------------ olaylar */
  function bindEvents() {
    cityBtn.addEventListener('click', function () { openSheet('city', false); });
    $('settingsBtn').addEventListener('click', function () { openSheet('settings', false); });
    scrimEl.addEventListener('click', closeSheet);
    document.addEventListener('click', function (e) {
      var c = e.target.closest ? e.target.closest('[data-close]') : null;
      if (c) { closeSheet(); }
    });

    cityListEl.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('.city-item') : null;
      if (b) { selectCity(b.getAttribute('data-name')); }
    });
    cityQueryEl.addEventListener('input', filterCities);
    geoBtn.addEventListener('click', function () { requestGeo(true); });

    $('settingsSheet').addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button[data-d]') : null;
      if (!b) { return; }
      var row = b.closest('.stepper'), k = row.getAttribute('data-k');
      state.kerahat[k] = clamp(state.kerahat[k] + (+b.getAttribute('data-d')), LIMITS[k][0], LIMITS[k][1]);
      saveState();
      syncSettings();
      if (b.disabled) {
        var other = row.querySelector('button:not(:disabled)');
        if (other) { other.focus(); }
      }
      tick();
    });
    $('resetBtn').addEventListener('click', function () {
      KERAHAT_KEYS.forEach(function (k) { state.kerahat[k] = E.DEFAULTS.kerahat[k]; });
      saveState();
      syncSettings();
      tick();
    });

    document.addEventListener('keydown', function (e) {
      if (!current) { return; }
      if (e.key === 'Escape') { e.preventDefault(); closeSheet(); return; }
      if (e.key !== 'Tab') { return; }
      var f = focusables(current);
      if (!f.length) { return; }
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && (document.activeElement === first || document.activeElement === current)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });

    document.addEventListener('visibilitychange', function () { if (!document.hidden) { tick(); } });
    window.addEventListener('pageshow', tick);
  }

  /* ------------------------------------------------------------------ Android'in çağırdığı kancalar */
  window.__onBack = function () { return closeSheet(); };
  window.__onLocation = onLocation;
  window.__onLocationError = onLocationError;
  window.__onSystemTheme = function (dark) { applyTheme(!!dark); };
  window.__onResume = tick;

  /* ------------------------------------------------------------------ başlat */
  applyTheme(systemDark());
  makeClock(dialTimeEl);
  makeClock(nextCountEl);
  buildCityList();
  bindEvents();
  syncSettings();
  tick();
  if (!state.seen) {
    state.seen = true;
    saveState();
    window.setTimeout(function () { openSheet('city', true); }, 500);
  } else if (state.mode === 'gps') {
    requestGeo(false);
  }
})();
